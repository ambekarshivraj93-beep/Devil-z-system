DEVIL'S SYSTEM - BATCH 2

Contains:
- app/build.gradle.kts
- app/src/main/AndroidManifest.xml
- app/src/main/java/com/devilssystem/devil/MainActivity.kt
- gradle/wrapper/gradle-wrapper.properties

Important:
This is a starter Android app shell, not a completed AI assistant and not a verified APK.
The chat screen is a UI preview. It does not call an AI model or save chat history yet.
Room dependencies are included for the upcoming memory implementation. MediaPipe is deliberately
not added until the actual inference code and compatible model format are checked.

Expected root plugin versions in the existing root build.gradle.kts:
- Android Gradle Plugin 8.7.3
- Kotlin Android 2.0.21
- Kotlin Compose plugin 2.0.21
- KSP 2.0.21-1.0.28

Expected Gradle distribution: 8.9. A complete project also needs settings.gradle.kts,
root build.gradle.kts, gradle.properties, Gradle wrapper scripts/JAR, and the remaining source files.
Compile/build has NOT been run in this environment.
