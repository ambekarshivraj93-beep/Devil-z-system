package com.devilssystem.devil

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Void = Color(0xFF070709)
private val Panel = Color(0xFF151519)
private val BloodRed = Color(0xFFD90429)
private val MainText = Color(0xFFF3F3F5)
private val Muted = Color(0xFF92929B)

private data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                DevilHome()
            }
        }
    }
}

@Composable
private fun DevilHome() {
    val messages = remember {
        mutableStateListOf(
            ChatMessage("DEVIL V1.0 GENESIS is online.", false),
            ChatMessage("Core interface initialized. AI model is not connected yet.", false)
        )
    }
    var input by remember { mutableStateOf("") }

    Surface(modifier = Modifier.fillMaxSize(), color = Void) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("DEVIL'S SYSTEM", color = MainText, fontSize = 19.sp, fontWeight = FontWeight.Black)
                    Text("V1.0  /  GENESIS", color = BloodRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Text("●  LOCAL SHELL", color = Muted, fontSize = 10.sp)
            }

            Spacer(Modifier.padding(top = 18.dp))
            Box(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)) {
                Column {
                    Text("TERMINAL", color = BloodRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("DEVIL", color = MainText, fontSize = 27.sp, fontWeight = FontWeight.Black)
                    Text("Your personal assistant interface", color = Muted, fontSize = 12.sp)
                }
            }

            Spacer(Modifier.padding(top = 14.dp))
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { message ->
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = if (message.fromUser) Alignment.End else Alignment.Start
                    ) {
                        Text(
                            if (message.fromUser) "YOU" else "DEVIL",
                            color = if (message.fromUser) Muted else BloodRed,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier.background(Panel, RoundedCornerShape(12.dp)).padding(12.dp)
                        ) {
                            Text(message.text, color = MainText, fontSize = 14.sp)
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 10.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 14.sp),
                    singleLine = true,
                    decorationBox = { inner ->
                        Box {
                            if (input.isEmpty()) Text("Message DEVIL...", color = Muted, fontSize = 14.sp)
                            inner()
                        }
                    }
                )
                TextButton(onClick = {
                    val message = input.trim()
                    if (message.isNotEmpty()) {
                        messages.add(ChatMessage(message, true))
                        messages.add(ChatMessage("The interface is working, but the AI engine has not been connected yet.", false))
                        input = ""
                    }
                }) {
                    Text("SEND", color = BloodRed, fontWeight = FontWeight.Bold)
                }
            }
            Text("OFFLINE UI PREVIEW  •  MODEL NOT LOADED", color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}
