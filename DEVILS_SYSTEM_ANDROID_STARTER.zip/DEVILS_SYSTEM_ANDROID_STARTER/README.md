# DEVIL'S SYSTEM — Android starter project

This is a minimal Android/Jetpack Compose starter shell for DEVIL V1.0 Genesis.

## Current capabilities
- Launchable Compose chat-style interface.
- Local in-memory message list for the current app session only.
- Dark black/red visual theme.

## Not implemented yet
- No AI model/API connection.
- No persistent Room database integration yet (dependencies only).
- No voice input/output.
- No device-control skills.
- No offline model runtime.

## Build
The GitHub Actions workflow uses JDK 17 and Gradle 8.9 to run `gradle assembleDebug` and uploads the debug APK as an artifact. It intentionally does not require Gradle wrapper scripts/JAR in this starter.

The build has not been run yet. A successful GitHub Actions run is required before calling this APK build-verified.
