package com.devilssystem.devil

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Black = Color(0xFF090909)
private val Panel = Color(0xFF171313)
private val Red = Color(0xFFE32636)
private val White = Color(0xFFF4EEEE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("devil", MODE_PRIVATE)
        setContent {
            var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions") ?: "") }
            var model by remember { mutableStateOf(prefs.getString("model", "gpt-4o-mini") ?: "") }
            var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
            var mode by remember { mutableStateOf("AUTO") }
            var input by remember { mutableStateOf("") }
            var busy by remember { mutableStateOf(false) }
            var showSettings by remember { mutableStateOf(false) }
            val messages = remember {
                mutableStateListOf<Pair<Boolean, String>>().apply {
                    add(false to "DEVIL online. Choose AUTO, ONLINE, or OFFLINE and send a message.")
                    val old = prefs.getString("history", null)
                    if (old != null) try {
                        val arr = JSONArray(old)
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            add(o.getBoolean("user") to o.getString("text"))
                        }
                    } catch (_: Exception) {}
                }
            }
            val scope = rememberCoroutineScope()
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Red, background = Black, surface = Panel,
                onPrimary = White, onBackground = White, onSurface = White
            )) {
                Column(Modifier.fillMaxSize().background(Black).padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("DEVIL'S SYSTEM", color = Red, fontSize = 23.sp, fontWeight = FontWeight.Black)
                            Text("PERSONAL AI ASSISTANT  •  V1.1", color = White.copy(alpha=.65f), fontSize = 10.sp)
                        }
                        TextButton(onClick = { showSettings = !showSettings }) { Text("SETUP", color = Red) }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("AUTO", "ONLINE", "OFFLINE").forEach { item ->
                            FilterChip(selected = mode == item, onClick = { mode = item }, label = { Text(item) })
                        }
                    }
                    if (showSettings) {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("ONLINE AI SETTINGS", color = Red, fontWeight = FontWeight.Bold)
                                Field("API endpoint", endpoint) { endpoint = it; prefs.edit().putString("endpoint", it).apply() }
                                Field("Model", model) { model = it; prefs.edit().putString("model", it).apply() }
                                Field("API key", apiKey, true) { apiKey = it; prefs.edit().putString("key", it).apply() }
                                Text("Use an API key from a provider you trust. API usage may cost money.", color = White.copy(alpha=.6f), fontSize = 11.sp)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(messages) { (isUser, msg) ->
                            Column(Modifier.fillMaxWidth(), horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {
                                Surface(color = if (isUser) Color(0xFF3A1118) else Panel, shape = RoundedCornerShape(14.dp)) {
                                    Text(msg, Modifier.padding(12.dp), color = White, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BasicTextField(
                            value = input, onValueChange = { input = it },
                            modifier = Modifier.weight(1f).background(Panel, RoundedCornerShape(12.dp)).padding(14.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 15.sp),
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(Red),
                            decorationBox = { inner -> if (input.isEmpty()) Text("Message DEVIL...", color = White.copy(alpha=.4f)); inner() }
                        )
                        Button(onClick = {
                            val prompt = input.trim()
                            if (prompt.isNotEmpty() && !busy) {
                                input = ""; messages.add(true to prompt)
                                prefs.edit().putString("history", encode(messages)).apply()
                                busy = true
                                scope.launch {
                                    val reply = if (mode != "OFFLINE" && apiKey.isNotBlank()) {
                                        try { onlineReply(endpoint, model, apiKey, prompt) }
                                        catch (e: Exception) { "Online request failed: ${e.message}. Check endpoint, key, and internet." }
                                    } else offlineReply(prompt)
                                    messages.add(false to reply)
                                    prefs.edit().putString("history", encode(messages)).apply()
                                    busy = false
                                }
                            }
                        }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                            Text(if (busy) "..." else "SEND", color = White)
                        }
                    }
                    Text("Offline mode uses built-in commands; it is not a bundled generative LLM.", color = White.copy(alpha=.45f), fontSize = 10.sp, modifier = Modifier.padding(top=8.dp))
                }
            }
        }
    }
}

@Composable
private fun Field(label: String, value: String, secret: Boolean = false, onChange: (String) -> Unit) {
    Column {
        Text(label, color = White.copy(alpha=.65f), fontSize = 11.sp)
        OutlinedTextField(value, onChange, modifier = Modifier.fillMaxWidth(), singleLine = true,
            visualTransformation = if (secret) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None)
    }
}

private fun encode(messages: List<Pair<Boolean, String>>): String {
    val a = JSONArray()
    messages.takeLast(100).forEach { (u, t) -> a.put(JSONObject().put("user", u).put("text", t)) }
    return a.toString()
}

private fun offlineReply(prompt: String): String {
    val p = prompt.lowercase()
    return when {
        p in listOf("hi", "hello", "hey") -> "Greetings. DEVIL is ready. In this build, offline replies are limited to built-in commands."
        "time" in p -> "The current time is available from your phone's status bar."
        "who are you" in p || "introduce" in p -> "I am DEVIL, your personal assistant interface. Connect an AI API in SETUP for full online conversations."
        "help" in p -> "Try: introduce yourself, who are you, or connect an API key in SETUP and choose ONLINE."
        else -> "Offline mode is active, but this starter build has no local language model. Connect an API key in SETUP and choose ONLINE for generative AI."
    }
}

private suspend fun onlineReply(endpoint: String, model: String, key: String, prompt: String): String =
    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val conn = (URL(endpoint).openConnection() as HttpURLConnection)
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 30000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Authorization", "Bearer $key")
            val body = JSONObject()
                .put("model", model)
                .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", "You are DEVIL, a helpful personal AI assistant. Be clear, capable, and honest.")).put(JSONObject().put("role", "user").put("content", prompt)))
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}: ${response.take(400)}")
            JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        } finally { conn.disconnect() }
    }
