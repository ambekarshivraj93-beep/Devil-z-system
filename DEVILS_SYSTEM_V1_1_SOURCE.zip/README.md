# DEVIL'S SYSTEM V1.1

Android starter app with a black/red Compose interface, chat history, configurable OpenAI-compatible chat-completions endpoint, and basic built-in offline responses.

## Build
Open this project with Android Studio or use the repository GitHub Actions workflow at `.github/workflows/build-apk.yml`.

## Important limitations
- This is a starter build, not a verified release.
- Online AI requires an API endpoint, model, API key, and internet connection. API use may cost money.
- Offline mode is a small built-in command fallback, **not** a bundled local generative model.
- No voice features or device-control permissions are implemented.
- API key is stored in app-private preferences. Do not share the device or APK with untrusted people.
